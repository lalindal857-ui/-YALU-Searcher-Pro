YALU SEARCHER PRO — LAKSHAN BRANDED BUILD

Updates requested:
- Your supplied Journal Entry Searcher artwork is shown in the app header.
- The same artwork is used as the Windows application icon.
- App title: YALU Searcher Pro.
- Compact floating window.
- Search by Entry No.; auto-copy Description with (Entry No. / Line No.) at the end.
- After copying, a separate small notification appears: “Prepared By Lakshan”.
- The notification is separate; it is NOT added to the copied Description text.
- Cost Center only is displayed; Posting Date is not shown.

Build on GitHub:
1. Create/open your private repository.
2. Upload all files from this ZIP, including the hidden .github folder.
3. Commit changes.
4. Actions > Build YALU Searcher EXE > Run workflow.
5. Download artifact YALU-Searcher-Windows, extract, run YALU_Searcher.exe.

This ZIP is a source/build package, not the compiled EXE. The Excel report is selected
locally inside the app. Keep company/financial reports private.
